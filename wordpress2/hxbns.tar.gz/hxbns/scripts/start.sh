#!/bin/bash
sadb=`awk -F"=" '/^sadb=/{print $2}' /data/hxbns/conf.txt`
sadbuser=`awk -F"=" '/^sadbuser=/{print $2}' /data/hxbns/conf.txt`
sadbuserpass=`awk -F"=" '/^sadbuserpass=/{print $2}' /data/hxbns/conf.txt`
ip=$1
action=$2
PATH=/usr/local/bin:/usr/local/sbin:/usr/bin:/usr/sbin:/bin:/sbin:$HOME/bin
server=`mysql -h${sadb} -u${sadbuser} -p${sadbuserpass} -e "USE hxbns_manage;SELECT GsiD FROM configdb WHERE Externalip='${ip}'"`
servername=`echo $server | awk -F" " '{print $2}'`
echo "server dirctory is hx_mainland_${servername}"
#        sh /data/script/myservice $servername start $modules
process=`ss -tan | grep beam | wc -l`
if [[ $process -gt 0 ]]
then
	echo  -e "\033[31m 选择的"hx_mainland_${servername}"个别进程正在运行，请检查一下!\033[0m" && exit
else
	cd /data/script/BatchManager/;/usr/bin/python2.6 BatchManager.py hx_mainland_${servername} $action
fi
if [[ $action == "start" ]]
then
	if [[ $process -eq 5 ]]
	then
		echo "the server hx_mainland_${servername} starting success"
	else
		echo "the server hx_mainland_${servername} starting failure"
	fi
elif [[ $action == "stop" ]]
	if [[ $process -eq 5 ]]
        then
                echo "the server hx_mainland_${servername} stop failure"
        elif [[ $process -eq 0 ]]
                echo "the server hx_mainland_${servername} stop failure"
        fi
fi
