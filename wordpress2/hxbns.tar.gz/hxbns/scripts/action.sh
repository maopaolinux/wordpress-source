#!/bin/bash
IP=$1
action=$2
#scp ./script/start.sh $Ip:/data/script/start.sh
ssh $IP "sh /data/hxbns/scripts/start.sh $IP $action"
