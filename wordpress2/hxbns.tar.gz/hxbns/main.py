#!/usr/bin/env python2.6
#coding:utf-8
#encodinf=utf-8
#author:luodi date:2014/10/23
#descriptions:this is a exec program main.
#version:v1.0 mtime:2014/10/24
from connection import *
import os,subprocess
import sys,time
import threading
def testinput():
    if len(sys.argv) < 2:
        print 'Usage:python2.6 main.py {start|stop|jion} area servers'
        sys.exit(1)
    elif len(sys.argv) < 3:
         allarea = ['andr','app','tg','tx','tw','xm','yn','yh','jp','bm','els','kakao','ouz']
         print '''andr=安卓  app=AppStore  tg=泰国
tx=腾讯    tw=台湾       yn=越南
yh=硬核    jp=日本       bm=北美
els=俄罗斯 ouz=欧洲      kakao=韩国'''
#         print allarea
         sys.exit(1)
    elif len(sys.argv) < 4:
         andr = sys.argv[2]
         cursor = conn.cursor()
         count = cursor.execute('select ServerName from configdb JOIN region_info ON region_info.iD=configdb.RegionID WHERE region_info.name="%s"' % andr)
         result = cursor.fetchall()
         print "The area",andr," has",count," server you can choice,"
         for i in range(count):
             print result[i][0];
         print"\033[31m可以使用all代表所有服务器\033[0m"
         sys.exit(1)
#    elif len(sys.argv) > 4:
#         print "too more argvs,"
#         exit(1)
    else:
        oper = sys.argv[1]
        area = sys.argv[2]
        server = sys.argv[3:]
def operater(ip):
    if oper == "start":
        os.system("/bin/bash" ' ' + './scripts/action.sh' ' ' + ip + ' ' + 'start')
    elif oper == "stop":
        os.system("/bin/bash" ' ' + './scripts/action.sh' ' ' + ip + ' ' + 'stop')
    elif oper == "join":
        os.system("/usr/bin/python2.6 ./scripts/join.sh")
    else:
        print "your input error plz check it!"
def getserverinfo():
    cursor = conn.cursor()
    count = cursor.execute('select configdb.Externalip from configdb JOIN region_info ON configdb.RegionID=region_info.iD WHERE configdb.ServerName="%s"' % server)
    result = cursor.fetchone()
    for i in result:
        print "%s server %s" %(oper,i)
        operater(i)
def getserverinfo1():
    cursor = conn.cursor()
#    count = cursor.execute('select configdb.Externalip from configdb JOIN region_info ON configdb.RegionID=region_info.iD WHERE RegionID IN (SELECT iD FROM region_info WHERE region_info.name="%area")')
    count = cursor.execute('select configdb.Externalip from configdb JOIN region_info ON configdb.RegionID=region_info.iD WHERE configdb.RegionID=(SELECT iD FROM region_info WHERE region_info.name="%s")' % area)
    result = cursor.fetchall()
    print result
    for x in range(count):
        i = result[x][0]
        server = result[x][0]
        print "%s server %s" %(oper,i)
        operater(i)


#---------------------主程序--------------------

if len(sys.argv) <= 4:
    testinput()
    oper = sys.argv[1]
    area = sys.argv[2]
    server = sys.argv[3]
    if server == "all":
        getserverinfo1()
    else:
        getserverinfo()
else:
    testinput()
    oper = sys.argv[1]
    area = sys.argv[2]
    servers = sys.argv[3:]
    for i in servers:
        print i
        server = i
        getserverinfo()

