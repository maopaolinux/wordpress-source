#!/usr/bin/env python2.6
#coding=utf-8
#author:luodi date:2014/10/20
#descriptions:The model's update system's connection model
import MySQLdb
def Conn():
    conn=MySQLdb.connect(host='127.0.0.1',user='admin',passwd='admin',db='hxbns_manage',charset="utf8",port=3306)
    cur=conn.cursor()
    return conn,cur

if __name__ == "__main__":
    pass
else:
    conn,cur=Conn()
